from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from routers import analyze

app = FastAPI(
    title="Analyze-This · CV Optimizer ATS",
    description="Optimiza tu CV para cualquier oferta laboral con IA",
    version="2.0.0",
)

app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(analyze.router)
