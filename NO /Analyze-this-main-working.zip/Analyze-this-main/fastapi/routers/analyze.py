"""
Main analysis routes — the core of Phase 1.
"""
import uuid
import time
from typing import Optional
from fastapi import APIRouter, Request, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from config import get_settings
from services.claude import optimize_cv
from services.extractor import extract_pdf, extract_docx, scrape_job_url, is_valid_url
from services.builder import DOCX_BUILDERS, build_cv_pdf, TEMPLATES_META

router = APIRouter()
templates = Jinja2Templates(directory="templates")

# ─── In-memory result cache (Phase 1 — no auth/DB needed) ─────────────────────
# { result_id: { "data": cv_dict, "ts": float } }
_result_cache: dict = {}
_CACHE_TTL = 3600  # 1 hour


def _store_result(cv_data: dict) -> str:
    result_id = str(uuid.uuid4())
    _result_cache[result_id] = {"data": cv_data, "ts": time.time()}
    # Clean expired entries
    now = time.time()
    expired = [k for k, v in _result_cache.items() if now - v["ts"] > _CACHE_TTL]
    for k in expired:
        del _result_cache[k]
    return result_id


def _get_result(result_id: str) -> Optional[dict]:
    entry = _result_cache.get(result_id)
    if not entry:
        return None
    if time.time() - entry["ts"] > _CACHE_TTL:
        del _result_cache[result_id]
        return None
    return entry["data"]


# ─── Routes ────────────────────────────────────────────────────────────────────

@router.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@router.post("/analyze", response_class=HTMLResponse)
async def analyze(
    request: Request,
    cv_file: Optional[UploadFile] = File(None),
    cv_text_raw: str = Form(""),
    job_input: str = Form(""),
    max_pages: int = Form(2),
    font_size: float = Form(11.0),
    career_change: bool = Form(False),
    cv_only: bool = Form(False),
    output_lang: str = Form("es"),
):
    settings = get_settings()
    if not settings.anthropic_api_key:
        return templates.TemplateResponse("index.html", {
            "request": request,
            "error": "No se encontró ANTHROPIC_API_KEY. Configura la variable de entorno."
        })

    # ── Extract CV text ────────────────────────────────────────────────────────
    cv_text = ""
    if cv_file and cv_file.filename:
        file_bytes = await cv_file.read()
        fname = cv_file.filename.lower()
        try:
            if fname.endswith(".pdf"):
                cv_text = extract_pdf(file_bytes)
            elif fname.endswith(".docx"):
                cv_text = extract_docx(file_bytes)
            else:
                return templates.TemplateResponse("index.html", {
                    "request": request,
                    "error": "Formato de CV no soportado. Sube un PDF o DOCX."
                })
        except Exception as e:
            return templates.TemplateResponse("index.html", {
                "request": request,
                "error": f"Error al leer el archivo: {e}"
            })
    elif cv_text_raw.strip():
        cv_text = cv_text_raw.strip()

    if not cv_text:
        return templates.TemplateResponse("index.html", {
            "request": request,
            "error": "Sube un CV o pega el texto directamente."
        })

    # ── Extract job text ───────────────────────────────────────────────────────
    job_text = ""
    job_input = job_input.strip()
    if is_valid_url(job_input):
        try:
            job_text = scrape_job_url(job_input)
        except ValueError as e:
            return templates.TemplateResponse("index.html", {
                "request": request,
                "error": str(e),
                "cv_text_raw": cv_text_raw,
            })
    elif job_input:
        job_text = job_input

    if not job_text and not cv_only:
        # No job → force cv_only mode
        cv_only = True

    # ── Run Claude ─────────────────────────────────────────────────────────────
    try:
        cv_data = optimize_cv(
            cv_text=cv_text,
            job_text=job_text,
            max_pages=max_pages,
            font_size=font_size,
            api_key=settings.anthropic_api_key,
            career_change=career_change,
            cv_only=cv_only,
            output_lang=output_lang,
        )
    except Exception as e:
        return templates.TemplateResponse("index.html", {
            "request": request,
            "error": f"Error al analizar con Claude: {e}"
        })

    result_id = _store_result(cv_data)

    return templates.TemplateResponse("results.html", {
        "request": request,
        "cv": cv_data,
        "result_id": result_id,
        "templates_meta": TEMPLATES_META,
        "score": cv_data.get("score_match", 0),
        "ats_ok": cv_data.get("ats_compatible", True),
        "ats_detected": cv_data.get("ats_detectado", ""),
        "ats_reason": cv_data.get("ats_razon", ""),
        "score_explain": cv_data.get("score_explicacion", ""),
        "score_desglose": cv_data.get("score_desglose", {}),
        "keywords_ok": cv_data.get("keywords_integradas", []),
        "keywords_miss": cv_data.get("keywords_faltantes", []),
        "coaching": cv_data.get("coaching", []),
        "was_truncated": cv_data.get("_was_truncated", False),
        "model_used": cv_data.get("_model_used", "haiku"),
    })


@router.get("/download/{result_id}")
async def download(result_id: str, fmt: str = "docx", template: str = "Clásico"):
    cv_data = _get_result(result_id)
    if not cv_data:
        raise HTTPException(status_code=404, detail="Resultado expirado. Vuelve a analizar tu CV.")

    nombre = cv_data.get("nombre", "CV").replace(" ", "_")

    if fmt == "docx":
        builder = DOCX_BUILDERS.get(template, DOCX_BUILDERS["Clásico"])
        buf = builder(cv_data)
        filename = f"CV_{nombre}_{template}.docx"
        media_type = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    elif fmt == "pdf":
        buf = build_cv_pdf(cv_data, template)
        filename = f"CV_{nombre}_{template}.pdf"
        media_type = "application/pdf"
    else:
        raise HTTPException(status_code=400, detail="Formato no soportado. Usa 'docx' o 'pdf'.")

    return StreamingResponse(
        buf,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
